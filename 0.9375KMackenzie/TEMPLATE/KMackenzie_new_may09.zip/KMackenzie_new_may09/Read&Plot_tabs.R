# Script that reads the output of GEOtop and plots the Results
# Author: Matteo Dall'Amico
# for info: matteo@mountain-eering.com
# 
###############################################################################

fileInfoScript<-paste(getwd(),"InfoScriptR.txt",sep="/");


## DEFINE THE DEPTH WHERE YOU WANT THE PLOTS in the time (interpolate)
z_star<-scan(fileInfoScript, skip=2,nlines=1,sep=","); # [m]
z_star<-z_star*1000;# [mm]

# Define whether you are interested in the instantaneous (INST) or mean (MEAN) files
typ_fil<-scan(fileInfoScript, skip=4,nlines=1,what=character());
print(paste("You want to plot the ", typ_fil, " output files"));

# *************************************************************************
# FILE NAMES
# *************************************************************************
#output files
fileSnow<-paste(getwd(),"output/tabs/09_SNOWz0001.txt",sep="/");
fileFlow<-paste(getwd(),"output/tabs/01_flows.txt",sep="/");
fileBasin<-paste(getwd(),"output/tabs/02_basin.txt",sep="/");
filePoint<-paste(getwd(),"output/tabs/04_point0001.txt",sep="/");
fileInfoP<-paste(getwd(),"output/tabs/04_point_info_0001.txt",sep="/");
fileMeteo<-paste(getwd(),"meteo/_meteo0001.txt",sep="/");

if (typ_fil=="INST") {
	fileT<-paste(getwd(),"output/tabs/05_Tz0001.txt",sep="/");
	filePsi<-paste(getwd(),"output/tabs/06_psiz0001.txt",sep="/");
	fileThetaW<-paste(getwd(),"output/tabs/07_THETAz0001.txt",sep="/");
	fileThetaI<-paste(getwd(),"output/tabs/08_THETAICEz0001.txt",sep="/");
} else {
	fileT<-paste(getwd(),"output/tabs/05_Tz_MEAN0001.txt",sep="/");
	filePsi<-paste(getwd(),"output/tabs/06_psiz_MEAN0001.txt",sep="/");
	fileThetaW<-paste(getwd(),"output/tabs/07_THETAz_MEAN0001.txt",sep="/");
	fileThetaI<-paste(getwd(),"output/tabs/08_THETAICEz_MEAN0001.txt",sep="/");
}

# get working directory
dir.create(paste(getwd(),"plot",sep="/") );
pathdirplot<-paste(getwd(),"plot","",sep="/");


##input files
#fileMeteo<-paste(getwd(),"meteo/_meteo0001.txt",sep="/");

# READ PARAMETERS
d<-scan(fileInfoP, skip=8,nlines=1,sep=","); # [mm]
print("soil layer thickness [mm]"); d;

c<-scan(fileInfoP, skip=10,nlines=1,sep=","); # [mm]
print("z coordinate of the center of each soil layer [mm]"); c;

# READ SOIL VAN GENUCHTEN PARAMETERS
theta_r<-scan(fileInfoP, skip=12,nlines=1,sep=","); # [-]
print("theta_r [-]"); theta_r;

theta_s<-scan(fileInfoP, skip=14,nlines=1,sep=","); # [-]
print("theta_s [-]"); theta_s;

alpha<-scan(fileInfoP, skip=16,nlines=1,sep=","); # [mm^-1]
print("alpha [mm^-1]"); alpha;

n<-scan(fileInfoP, skip=18,nlines=1,sep=","); # [-]
print("n [-]"); n;

Kv_sat<-scan(fileInfoP, skip=24,nlines=1,sep=","); # [mm/s]
print("Kv_sat [mm/s]"); Kv_sat;

Kh_sat<-scan(fileInfoP, skip=26,nlines=1,sep=","); # [mm/s]
print("Kh_sat [mm/s]"); Kh_sat;

C_t<-scan(fileInfoP, skip=28,nlines=1,sep=","); # [mm/s]
print("C_t [J/(m3 K)]"); C_t;

lambda<-scan(fileInfoP, skip=30,nlines=1,sep=","); # [mm/s]
print("lambda [W/(m K)]"); lambda;

# *************************************************************************
# IMPORT METEO DATA
# *************************************************************************
print("load the meteo data");
Meteo<-read.table(fileMeteo,header=TRUE,sep=",",skip=0,check.names=FALSE);
Meteo$POSIX<-as.POSIXct(strptime(Meteo$Date,"%d/%m/%y %H:%M"),"CET");


# *************************************************************************
# IMPORT SIMULATED DATA
# *************************************************************************
print("load the simulated data");
SimFlow<-read.table(fileFlow,header=TRUE,sep=",",skip=0,check.names=FALSE);
SimBasin<-read.table(fileBasin,header=TRUE,sep=",",skip=0,check.names=FALSE);
SimPoint<-read.table(filePoint,header=TRUE,sep=",",skip=0,check.names=FALSE);
SimTz<-read.table(fileT,header=TRUE,sep=",",skip=0,check.names=FALSE);
SimPsi<-read.table(filePsi,header=TRUE,sep=",",skip=0,check.names=FALSE);
SimThetaW<-read.table(fileThetaW,header=TRUE,sep=",",skip=0,check.names=FALSE);
SimThetaI<-read.table(fileThetaI,header=TRUE,sep=",",skip=0,check.names=FALSE);
#meteo<-read.table(fileMeteo,header=TRUE,sep=",",skip=0,check.names=FALSE);
#SimSnow<-read.table(fileSnow,header=TRUE,sep=",",skip=0,na.strings="-99",check.names=FALSE);

SimFlow$POSIX<-as.POSIXct(strptime(SimFlow$DATE,"%d/%m/%Y %H:%M"),"CET");
SimTz$POSIX<-as.POSIXct(strptime(SimTz$DATE,"%d/%m/%Y %H:%M"),"CET");
SimThetaW$POSIX<-as.POSIXct(strptime(SimThetaW$DATE,"%d/%m/%Y %H:%M"),"CET");
SimThetaI$POSIX<-as.POSIXct(strptime(SimThetaI$DATE,"%d/%m/%Y %H:%M"),"CET");
SimPoint$POSIX<-as.POSIXct(strptime(SimPoint[,1],"%d/%m/%Y %H:%M"),"CET");
SimPsi$POSIX<-as.POSIXct(strptime(SimPsi[,1],"%d/%m/%Y %H:%M"),"CET");
#meteo$POSIX<-as.POSIXct(strptime(meteo[,1],"%d/%m/%Y %H:%M"),"CET");
#SimSnow$POSIX<-as.POSIXct(strptime(SimSnow$DATE,"%d/%m/%Y %H:%M"),"CET");


# *************************************************************************
# PLOT 
# *************************************************************************

# if you want to zoom a date window
#date_from_plot<-as.POSIXct("2003-09-16 12:00:00","CET");
#date_to_plot<-as.POSIXct("2004-07-15 00:00:00","CET");
date_from_plot<-SimTz$POSIX[1];
date_to_plot<-SimTz$POSIX[length(SimTz$POSIX)];


c1<-c*-1; # in this way it is possible to have the highest value on top that coincides with soil surface
#PLOT PROFILE: SOIL_DEPTH-TEMPERATURE at different times
temp<-SimTz[,-(1:4)];
temp<-temp[,-(ncol(temp))];
temp_trasp<-as.data.frame(t(as.matrix(data.frame(temp))));#traspose the data frame: now the columns are the time, and the rows the soil depths
Tmin<-min(SimTz[,(5:(ncol(SimTz)-1))]);
Tmax<-max(SimTz[,(5:(ncol(SimTz)-1))]);


# PLOT against the TIME various variables at different depth
for (j in 1:4){
	if (j==1) { 
		Sim<-SimTz;
		pdf(paste(pathdirplot,"Temp_time.pdf",sep="")); 
		ylb<-"Temp [ C]";
		titl<-"Temperature";
	}
	if (j==2) { 
		Sim<-SimThetaW;
		pdf(paste(pathdirplot,"ThetaW_time.pdf",sep=""));
		ylb<-"ThetaW [-]";
		titl<-"ThetaW";
	}
	if (j==3) { 
		Sim<-SimThetaI;
		pdf(paste(pathdirplot,"ThetaI_time.pdf",sep=""));
		ylb<-"ThetaI [-]";
		titl<-"ThetaI";
	}
	if (j==4) { 
		Sim<-SimPsi;
		pdf(paste(pathdirplot,"Psi_time.pdf",sep=""));
		ylb<-"Psi [mm]";
		titl<-"Suction";
	}
	Minn<-min(Sim[,(5:(ncol(Sim)-1))]);
	Maxx<-max(Sim[,(5:(ncol(Sim)-1))]);
	plot(Sim$POSIX,Sim[,5],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
	#axis(1,at=seq(date_from_plot,date_to_plot,by='days')); # writhe the x axis every 30 days
	#axis(2,at=round(seq(Tmin,Tmax),0)); # write the y axis
	title(main=paste(titl," in time at different depths",sep=""),sub="");
	i<-1;
	while (z_star[i]<c[length(c)] && i<=length(z_star)) {
		up<-c[1]; # upper layer than z_star
		dw<-c[1]; # lower layer than z_star
		# find the upper and lower layer with which to interpolate
		for(k in 2:length(c)) {
			if (c[k]>=z_star[i] && c[k-1]<z_star[i]) {
				dw<-c[k];
				up<-c[k-1];
				break;
			}
		}
		#print(z_star[i]);print(up);print(dw);
		T_star<-Sim[,which(names(Sim)==up)]+ (z_star[i]-up)/(dw-up)*( Sim[,which(names(Sim)==dw)] - Sim[,which(names(Sim)==up)] );
		if (up==dw) {
			T_star<-Sim[,which(names(Sim)==up)];
		}
		lines(Sim$POSIX,T_star,lty=1,lwd=1,col=i);
		legend(date_from_plot,Maxx-(Maxx-Minn)*(i-1)/length(z_star),paste(z_star[i]/1000,"m"),col=i,lty=1,bty="n",cex=1.1);
		i<-i+1;
	}
	#plot 2D
	temp<-Sim[,-(1:4)];
	temp<-temp[,-(ncol(temp))];
	temp_trasp<-as.data.frame(t(as.matrix(data.frame(temp))));#traspose the data frame: now the columns are the time, and the rows the soil depths
	names_decreasing<-sort(as.numeric(names(temp)),decreasing=TRUE);
	temp1<-subset(temp,select=as.character(names_decreasing));
	filled.contour(Sim$POSIX,-sort(c,decreasing=TRUE)/1000,as.matrix(temp1),main=paste(titl," evolution in depth with time",sep=""),
#		plot.axes = { axis(1,at=seq(date_from_plot,date_to_plot,by="days"));
#			axis(2,seq(0,round(c1[length(c1)]/1000,1))) },
			#col=grey(seq(from=0.5,to=1,by =1/(Tmax-Tmin)/2)),
			nlevels=10,xlab="time",ylab="depth [m]",key.title=title(main=ylb));
# oppure: image(SimTz$JD/day,-sort(c,decreasing=TRUE)/1000,as.matrix(temp1))
	dev.off();
}

# DISCHARGE
pdf(paste(pathdirplot,"Q_time.pdf",sep=""));
Sim<-SimFlow;
ylb<-"Discharge [m3/s]";
Minn<-min(Sim[,(5:(ncol(Sim)-1))]);
Maxx<-max(Sim[,(5:(ncol(Sim)-1))]);
plot(Sim$POSIX,Sim[,5],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
title(main="Discharge (sup and sub) in time",sub="");
for (i in 1:3) {
	lines(Sim$POSIX,Sim[,5+i-1],col=i);
	legend(date_from_plot,Maxx-(Maxx-Minn)*(i-1)/3,names(Sim)[5+i-1],col=i,lty=1,bty="n",cex=1.1);
}
dev.off();

# SNOW
pdf(paste(pathdirplot,"Snow.pdf",sep=""));
Sim<-SimPoint;
# plot Snow depth
Minn<-min(Sim[,75]); # lo stesso che usare SimSnow$Snowdepth
Maxx<-max(Sim[,75]);
ylb<-"SnowD [mm]";

plot(Sim$POSIX,Sim[,75],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
title(main="Snow depth [mm] in time",sub="");
lines(Sim$POSIX,Sim[,75],col=1);
#legend(date_from_plot,Maxx,names(Sim)[4+i-1],col=i,lty=1,bty="n",cex=1.1);
# plot Snow water equivalent (SWE)
Minn<-min(Sim[,76]);#lo stesso che usare SimSnow$"SWE[mm]"
Maxx<-max(Sim[,76]);
ylb<-"SWE [mm]";
plot(Sim$POSIX,Sim[,76],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
title(main="SWE [mm] in time",sub="");
lines(Sim$POSIX,Sim[,76],col=1);
dev.off();

# Turbolence fluxes
pdf(paste(pathdirplot,"Turb.pdf",sep=""));
Sim<-SimPoint;
# plot Net Radiation
Minn<-min(Sim[,28]);
Maxx<-max(Sim[,28]);
ylb<-"Net Radiation [W/m2]";
plot(Sim$POSIX,Sim[,28],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
title(main="Net Radiation on the pixel in time",sub="");
lines(Sim$POSIX,Sim[,28],col=1);
#legend(date_from_plot,Maxx,names(Sim)[4+i-1],col=i,lty=1,bty="n",cex=1.1);

# sensible heat (H)
Minn<-min(Sim[,31]);
Maxx<-max(Sim[,31]);
ylb<-"H [W/m2]";
plot(Sim$POSIX,Sim[,31],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
title(main="Sensible heat flux [W/m2] in time",sub="");
lines(Sim$POSIX,Sim[,31],col=1);
# Latent heat (LE)
Minn<-min(Sim[,32]);
Maxx<-max(Sim[,32]);
ylb<-"H [W/m2]";
plot(Sim$POSIX,Sim[,32],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot),cex=1.1 );
title(main="Latent heat flux [W/m2] in time",sub="");
lines(Sim$POSIX,Sim[,32],col=1);

# total plot
Minn<-min(Sim[,(29:35)]);
Maxx<-max(Sim[,(29:35)]);
ylb<-"Energy flux [W/m2]";
plot(Sim$POSIX,Sim[,32],xlab="time", type='n',lty=1, ylab=ylb,ylim=c(Minn*0.9,Maxx*1.1),xlim=c(date_from_plot,date_to_plot+3600*24*3),cex=1.1 );
title(main="Energy balance: SurfEB=SW+LW-H-LE",sub="");
lines(Sim$POSIX,Sim[,29],col=1);
lines(Sim$POSIX,Sim[,30],col=2);
lines(Sim$POSIX,Sim[,31],col=3);
lines(Sim$POSIX,Sim[,32],col=4);
lines(Sim$POSIX,Sim[,34],col=5);
legend(date_to_plot,Maxx,names(Sim)[29],col=1,lty=1,bty="n",cex=1.1);
legend(date_to_plot,Maxx-(Maxx-Minn)*1/5,names(Sim)[30],col=2,lty=1,bty="n",cex=1.1);
legend(date_to_plot,Maxx-(Maxx-Minn)*2/5,names(Sim)[31],col=3,lty=1,bty="n",cex=1.1);
legend(date_to_plot,Maxx-(Maxx-Minn)*3/5,names(Sim)[32],col=4,lty=1,bty="n",cex=1.1);
legend(date_to_plot,Maxx-(Maxx-Minn)*4/5,names(Sim)[35],col=5,lty=1,bty="n",cex=1.1);
dev.off();


# plot Meteo
pdf(paste(pathdirplot,"Meteo.pdf",sep=""));
for (i in 2:(ncol(Meteo)-1) ) {
	plot(Meteo$POSIX,Meteo[,i],type='l',ylab=names(Meteo)[i]);
	}
dev.off();

